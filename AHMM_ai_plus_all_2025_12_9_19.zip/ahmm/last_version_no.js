//AHMM最新版本号，此文件嵌入到ahmm.html中，用于判断是否更新
g_lastVersionNo = "ai⁺2025.12.9.19";
