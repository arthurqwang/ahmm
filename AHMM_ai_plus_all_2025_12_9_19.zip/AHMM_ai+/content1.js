/*
【本文件名】：content1.js
【最后修改日期】：2025.6.13
【作者】：王权 大系统观开放论坛
【功能】：
    被注入到目标网页的JS，从 [当前网页] 生成AHMM。
【其他说明】：
    本程序为浏览器扩展插件 AHMM+AI 的核心部分。该浏览器扩展基本情况如下：
        manifest.json 定义了浏览器扩展的基本信息和权限。
        popup.html 作为浏览器扩展的入口界面，用户在此界面选择从当前网页生成 AHMM，还是从自定义文本生成 AHMM。
        popup.js 根据用户选择的单选按钮，决定注入哪个脚本到当前活动页面：
        content1.js 为从当前网页生成AHMM，content2.js 为从用户自定义的文本生成AHMM。
        两个注入脚本文件中，都调用llmcaller.html，但传递的参数值 tf 不同。本脚本 tf=1
    注意：content.js运行在目标网页的上下文中（如https://example.com），被视为目标网页的一部分；而本地文件（如a.html）属于file://协议，
    所以两者属于不同源，即，本地JS不能直接访问目标网页的内容，localStorage等需要同源条件的功能都不可用。
*/


(async () => {

  // 设定当前脚本的 tf 值为 1，表示从当前网页生成AHMM。
  const text_from = "tf=1";   // url 参数
  // 获得当前页面的URL，传给服务器端的处理程序
  const webURL = window.location.href;
  
  // 调用服务器端LLM处理程序 llmcaller.html
  const llmCallerUrl = "http://www.holomind.com.cn/ahmm/ai/llmcaller.html?" + text_from + "&webURL=" + encodeURIComponent(webURL);
  window.open(llmCallerUrl, "_blank");

})();