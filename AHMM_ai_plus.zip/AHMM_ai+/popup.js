/*
【本文件名】：popup.js
【最后修改日期】：2025.7.1
【作者】：王权 大系统观开放论坛
【功能】：
    处理 popup.html 中的事件。根据用户选择的单选按钮，决定注入哪个脚本到当前活动页面，进而实现从网页或从自定义文本生成AHMM。
【其他说明】：
    本程序为浏览器扩展插件 AHMM+AI 的核心部分。该浏览器扩展基本情况如下：
        manifest.json 定义了浏览器扩展的基本信息和权限。
        popup.html 作为浏览器扩展的入口界面，用户在此界面选择从当前网页生成 AHMM，还是从自定义文本生成 AHMM。
        popup.js 根据用户选择的单选按钮，决定注入哪个脚本到当前活动页面：
        content1.js 为从当前网页生成AHMM，content2.js 为从用户自定义的文本生成AHMM。
        两个注入脚本文件中，都调用llmcaller.html，但传递的参数值 tf 不同。本脚本 tf=1
    注意：content.js运行在目标网页的上下文中（如https://example.com），被视为目标网页的一部分；而本地文件（如a.html）属于file://协议，
    所以两者属于不同源，即，本地JS不能直接访问目标网页的内容，localStorage等需要同源条件的功能都不可用。
*/


// 获取当前扩展的版本（从 manifest.json，要在此文件中标注版本号）
const currentVersion = chrome.runtime.getManifest().version;

// 版本号显示，从manifest.json读取的版本号
document.getElementById("version").textContent = "(V" + currentVersion + ")";

// 隐藏更新的红色提示
document.getElementById("version_check").style.display = "none";  

// 检查是否存在新版本，如存在则提示
checkForUpdates();

// 点击Go！后，向当前活动页面注入脚本
document.getElementById("openBtn").addEventListener("click", async () => {

  // 获取用户选择的单选按钮的值，决定注入哪个脚本
  let contentJS = "content1.js";   // 默认注入 content1.js
  if(getSelectedValue() == "dfn") {contentJS = "content2.js";}   // 如果选择了自定义文本，则注入 content2.js

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab.id) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [contentJS]
    });
  }

});   // document.getElementById("openBtn").addEventListener 结束

// 处理 BSV_link 的点击事件，打开大系统观网站。
// 打开大系统观网站。此处必须采取动态监听，不能使用popup.html中在BSV_link上添加的onclick事件。
// popup.html中<a>也不起作用，但为了让其显式地展现链接地址的下划线而使用了<a>
document.getElementById("BSV_link").addEventListener("click", async () => {
  window.open("http://www.holomind.com.cn", "_blank");
});



// *********************************************** 以下是function部分 ***************************************************
// *********************************************************************************************************************
// 子程序：检查版本更新
async function checkForUpdates() {

  try {
    const response = await fetch('http://www.holomind.com.cn/ahmm/ai/ai_last_version_no.json?timestamp=' + new Date().getTime());  // 该文件在服务器端保存最新版本号
    const data = await response.json();
    const latestVersion = data.version; 

    // 对比版本号，不同则提示
    if (latestVersion != currentVersion) {
      document.getElementById("version_check").style.display = "block";  
    } else {
      document.getElementById("version_check").style.display = "none";  
    }
  } catch (error) {
      document.getElementById("version_check").style.display = "none";  
  }
  
}

// 子程序：获取被选中的单选按钮的值，即，从网页，还是自定义文本
function getSelectedValue() {
  // 获取所有name为"text_from"的单选按钮
  const radios = document.getElementsByName("text_from");
  // 遍历单选按钮，找到被选中的项
  for (let i = 0; i < radios.length; i++) {
    if (radios[i].checked) {
      return radios[i].value; // 返回选中的值
    }
  }
  return null; // 如果没有选中项，返回null
}